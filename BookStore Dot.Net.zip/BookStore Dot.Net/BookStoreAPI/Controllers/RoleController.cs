﻿using BookStore.Models.Models;
using BookStore.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Net;

namespace BookStoreAPI.Controllers
{
    [ApiController]
    [Route("api/role")]
    public class RoleController : ControllerBase
    {
        RoleRepository _rolerepository = new RoleRepository();

        [HttpGet]
        [Route("role")]
        [ProducesResponseType(typeof(ListResponse<RoleModel>), (int)HttpStatusCode.OK)]
        public IActionResult GetRoles()
        {
            var roles = _rolerepository.GetRoles();
            ListResponse<RoleModel> results = new()
            {
                Results = roles.Results.Select(c => new RoleModel(c)),
                TotalRecords = roles.TotalRecords,
            };

            return Ok(results);
        }
    }
}
